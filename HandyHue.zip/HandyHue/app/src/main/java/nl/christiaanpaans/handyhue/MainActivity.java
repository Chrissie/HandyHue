package nl.christiaanpaans.handyhue;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.divyanshu.colorseekbar.ColorSeekBar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ColorSeekBar colorSeekBar = findViewById(R.id.color_seek_bar);
        colorSeekBar.setOnColorChangeListener(new ColorSeekBar.OnColorChangeListener() {
            @Override
            public void onColorChangeListener(int color) {
//                Color.colorToHSV(color, RoomFactory.getRoom(roomIndex).getLamp(lampIndex).getHSV());
            }
        });
    }


}
